from endstone.plugin import Plugin
from endstone.event import event_handler, BlockBreakEvent, BlockPlaceEvent, PlayerInteractEvent, ActorDamageEvent
from endstone.command import Command, CommandSender
from endstone import ColorFormat, Player
import toml
from pathlib import Path


class SpawnProtect(Plugin):
    api_version = "0.5"
    
    commands = {
        "setspawn": {
            "description": "Set spawn protection point",
            "usages": ["/setspawn"],
            "permissions": ["spawnprotect.setspawn"]
        }
    }
    
    permissions = {
        "spawnprotect.setspawn": {
            "description": "Allows setting spawn point",
            "default": "op"
        }
    }
    
    def __init__(self):
        super().__init__()
        self.spawn_location = None
        self.radius = 20
        self.spawn_config = {}
        
    def on_load(self) -> None:
        self.logger.info("Loading SpawnProtect plugin...")
        
    def on_enable(self) -> None:
        config_dir = Path(self.data_folder) / "spawnprotect"
        config_dir.mkdir(parents=True, exist_ok=True)
        
        config_path = config_dir / "config.toml"
        
        if config_path.exists():
            with open(config_path, 'r', encoding='utf-8') as f:
                cfg = toml.load(f)
                self.spawn_config = cfg
                self.radius = cfg.get('radius', 20)
        else:
            cfg = {
                'radius': 20,
                'message': 'You cannot do this near spawn!',
                'spawn_location': {
                    'x': 0,
                    'y': 64,
                    'z': 0,
                    'world': 'world'
                }
            }
            self.spawn_config = cfg
            with open(config_path, 'w', encoding='utf-8') as f:
                toml.dump(cfg, f)
        
        self.logger.info(f"SpawnProtect enabled! Protection radius: {self.radius} blocks")
        
        self.register_events(self)
    
    def on_disable(self) -> None:
        self.logger.info("SpawnProtect disabled!")
    
    def on_command(self, sender: CommandSender, command: Command, args: list[str]) -> bool:
        if command.name == "setspawn":
            return self.set_spawn_command(sender, command, args)
        return False
    
    def is_in_spawn_area(self, x: float, y: float, z: float) -> bool:
        spawn = self.spawn_config.get('spawn_location', {})
        spawn_x = spawn.get('x', 0)
        spawn_z = spawn.get('z', 0)
        
        distance = ((x - spawn_x) ** 2 + (z - spawn_z) ** 2) ** 0.5
        return distance <= self.radius
    
    def set_spawn_command(self, sender: CommandSender, command: Command, args: list[str]) -> bool:
        if not isinstance(sender, Player):
            sender.send_error_message("This command can only be used by a player!")
            return False
            
        if not sender.is_op:
            sender.send_error_message("You don't have permission to use this command!")
            return False
            
        if hasattr(sender, 'location'):
            loc = sender.location
            self.spawn_config['spawn_location'] = {
                'x': loc.x,
                'y': loc.y,
                'z': loc.z,
                'world': loc.world.name if hasattr(loc, 'world') else 'world'
            }
            
            config_path = Path(self.data_folder) / "spawnprotect" / "config.toml"
            with open(config_path, 'w', encoding='utf-8') as f:
                toml.dump(self.spawn_config, f)
            
            sender.send_message(f"{ColorFormat.GREEN}Spawn point set at: {loc.x:.1f}, {loc.y:.1f}, {loc.z:.1f}")
            self.logger.info(f"Spawn location set to: {loc.x:.1f}, {loc.y:.1f}, {loc.z:.1f}")
        
        return True
    
    @event_handler
    def on_block_break(self, event: BlockBreakEvent) -> None:
        block = event.block
        player = event.player
        
        if self.is_in_spawn_area(block.x, block.y, block.z):
            if not player.is_op:
                event.cancel()
                msg = self.spawn_config.get('message', 'You cannot break blocks near spawn!')
                player.send_error_message(msg)
    
    @event_handler
    def on_block_place(self, event: BlockPlaceEvent) -> None:
        block = event.block
        player = event.player
        
        if self.is_in_spawn_area(block.x, block.y, block.z):
            if not player.is_op:
                event.cancel()
                msg = self.spawn_config.get('message', 'You cannot place blocks near spawn!')
                player.send_error_message(msg)
    
    @event_handler
    def on_player_interact(self, event: PlayerInteractEvent) -> None:
        player = event.player
        
        if hasattr(event, 'block') and event.block:
            block = event.block
            if self.is_in_spawn_area(block.x, block.y, block.z):
                if not player.is_op:
                    event.cancel()
    
    @event_handler
    def on_actor_damage(self, event: ActorDamageEvent) -> None:
        actor = event.actor
        
        if hasattr(actor, 'location'):
            loc = actor.location
            if self.is_in_spawn_area(loc.x, loc.y, loc.z):
                if isinstance(actor, Player):
                    if not actor.is_op:
                        event.cancel()
                        actor.send_error_message("You cannot take damage near spawn!")
                else:
                    event.cancel()
