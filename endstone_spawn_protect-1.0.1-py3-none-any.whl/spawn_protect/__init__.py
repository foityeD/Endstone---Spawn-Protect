from endstone.plugin import Plugin
from endstone.event import event_handler, BlockBreakEvent, BlockPlaceEvent, PlayerInteractEvent, ActorDamageEvent, PlayerJoinEvent, PlayerQuitEvent, ActorExplodeEvent
from endstone.command import Command, CommandSender
from endstone import ColorFormat, Player
import toml
from pathlib import Path


class SpawnProtect(Plugin):
    api_version = "0.5"
    
    commands = {
        "setspawn": {
            "description": "Set spawn protection point",
            "usages": ["/setspawn"],
            "permissions": ["spawnprotect.setspawn"]
        }
    }
    
    permissions = {
        "spawnprotect.setspawn": {
            "description": "Allows setting spawn point",
            "default": "op"
        }
    }
    
    def __init__(self):
        super().__init__()
        self.spawn_location = None
        self.radius = 20
        self.spawn_config = {}
        self.player_in_safe_zone = {}
        
    def on_load(self) -> None:
        self.logger.info("Loading SpawnProtect plugin...")
        
    def on_enable(self) -> None:
        config_dir = Path(self.data_folder)
        config_dir.mkdir(parents=True, exist_ok=True)
        
        config_path = config_dir / "config.toml"
        
        if config_path.exists():
            with open(config_path, 'r', encoding='utf-8') as f:
                cfg = toml.load(f)
                self.spawn_config = cfg
                self.radius = cfg.get('radius', 20)
        else:
            cfg = {
                'radius': 20,
                'message': 'You cannot do this near spawn!',
                'in_safe_zone_message': 'Safe zone',
                'not_in_safe_zone_message': 'Not in Safe zone',
                'spawn_location': {
                    'x': 0,
                    'y': 64,
                    'z': 0,
                    'world': 'world'
                }
            }
            self.spawn_config = cfg
            
            config_content = """# SpawnProtect Configuration File
# All messages support Minecraft color codes using § symbol

# Protection radius in blocks from spawn point
radius = 20

# Error message shown when player tries to break/place blocks in protected area
message = "You cannot do this near spawn!"

# Message displayed when entering the safe zone (shown in actionbar)
# Color formatting: Use § codes (e.g., §a for green, §c for red, §l for bold)
in_safe_zone_message = "Safe zone"

# Message displayed when leaving the safe zone (shown in actionbar)
not_in_safe_zone_message = "Not in Safe zone"

# Spawn location coordinates (set using /setspawn command)
[spawn_location]
x = 0
y = 64
z = 0
world = "world"
"""
            
            with open(config_path, 'w', encoding='utf-8') as f:
                f.write(config_content)
        
        self.logger.info(f"SpawnProtect enabled! Protection radius: {self.radius} blocks")
        
        self.register_events(self)
        
        self.server.scheduler.run_task(self, self.check_players_zone, delay=0, period=20)
    
    def on_disable(self) -> None:
        self.logger.info("SpawnProtect disabled!")
    
    def on_command(self, sender: CommandSender, command: Command, args: list[str]) -> bool:
        if command.name == "setspawn":
            return self.set_spawn_command(sender, command, args)
        return False
    
    def is_in_spawn_area(self, x: float, y: float, z: float) -> bool:
        spawn = self.spawn_config.get('spawn_location', {})
        spawn_x = spawn.get('x', 0)
        spawn_z = spawn.get('z', 0)
        
        distance = ((x - spawn_x) ** 2 + (z - spawn_z) ** 2) ** 0.5
        return distance <= self.radius
    
    def set_spawn_command(self, sender: CommandSender, command: Command, args: list[str]) -> bool:
        if not isinstance(sender, Player):
            sender.send_error_message("This command can only be used by a player!")
            return False
            
        if not sender.is_op:
            sender.send_error_message("You don't have permission to use this command!")
            return False
            
        if hasattr(sender, 'location'):
            loc = sender.location
            self.spawn_config['spawn_location'] = {
                'x': loc.x,
                'y': loc.y,
                'z': loc.z,
                'world': loc.world.name if hasattr(loc, 'world') else 'world'
            }
            
            config_path = Path(self.data_folder) / "config.toml"
            with open(config_path, 'w', encoding='utf-8') as f:
                toml.dump(self.spawn_config, f)
            
            sender.send_message(f"{ColorFormat.GREEN}Spawn point set at: {loc.x:.1f}, {loc.y:.1f}, {loc.z:.1f}")
            self.logger.info(f"Spawn location set to: {loc.x:.1f}, {loc.y:.1f}, {loc.z:.1f}")
        
        return True
    
    def check_players_zone(self):
        for player in self.server.online_players:
            player_id = player.unique_id
            loc = player.location
            in_zone = self.is_in_spawn_area(loc.x, loc.y, loc.z)
            was_in_zone = self.player_in_safe_zone.get(player_id, False)
            
            if in_zone != was_in_zone:
                self.player_in_safe_zone[player_id] = in_zone
                
                if in_zone:
                    msg = self.spawn_config.get('in_safe_zone_message', 'Safe zone')
                    player.send_tip(f"{ColorFormat.GREEN}{ColorFormat.BOLD}{msg}")
                else:
                    msg = self.spawn_config.get('not_in_safe_zone_message', 'Not in Safe zone')
                    player.send_tip(f"{ColorFormat.RED}{ColorFormat.BOLD}{msg}")
    
    @event_handler
    def on_player_join(self, event: PlayerJoinEvent) -> None:
        player = event.player
        player_id = player.unique_id
        self.player_in_safe_zone[player_id] = False
    
    @event_handler
    def on_player_quit(self, event: PlayerQuitEvent) -> None:
        player = event.player
        player_id = player.unique_id
        
        if player_id in self.player_in_safe_zone:
            del self.player_in_safe_zone[player_id]
    
    @event_handler
    def on_block_break(self, event: BlockBreakEvent) -> None:
        block = event.block
        player = event.player
        
        if not player.is_op and self.is_in_spawn_area(block.x, block.y, block.z):
            event.cancel()
            msg = self.spawn_config.get('message', 'You cannot break blocks near spawn!')
            player.send_message(f"{ColorFormat.RED}{msg}")
    
    @event_handler
    def on_block_place(self, event: BlockPlaceEvent) -> None:
        block = event.block
        player = event.player
        
        if not player.is_op and self.is_in_spawn_area(block.x, block.y, block.z):
            event.cancel()
            msg = self.spawn_config.get('message', 'You cannot place blocks near spawn!')
            player.send_message(f"{ColorFormat.RED}{msg}")
    
    @event_handler
    def on_player_interact(self, event: PlayerInteractEvent) -> None:
        player = event.player
        
        if hasattr(event, 'block') and event.block:
            block = event.block
            if not player.is_op and self.is_in_spawn_area(block.x, block.y, block.z):
                event.cancel()
    
    @event_handler
    def on_actor_damage(self, event: ActorDamageEvent) -> None:
        actor = event.actor
        
        if hasattr(actor, 'location'):
            loc = actor.location
            if self.is_in_spawn_area(loc.x, loc.y, loc.z):
                if isinstance(actor, Player) and actor.is_op:
                    return
                event.cancel()
    
    @event_handler
    def on_actor_explode(self, event: ActorExplodeEvent) -> None:
        location = event.location
        
        if self.is_in_spawn_area(location.x, location.y, location.z):
            event.cancel()
